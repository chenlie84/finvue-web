FinVue Windows Docker 部署说明
================================

部署步骤：
=========

1. 确保 Docker Desktop 已安装并正常运行

2. 配置 Docker 镜像加速器（推荐）
   - 打开 Docker Desktop → Settings → Docker Engine
   - 添加配置：
     {
       "registry-mirrors": [
         "https://docker.m.daocloud.io",
         "https://docker.nju.edu.cn"
       ]
     }
   - 点击 Apply & Restart

3. 进入目录并构建启动
   cd finvue-deploy-win
   docker-compose up -d --build

   构建需要几分钟，请耐心等待

4. 访问应用
   http://localhost:8080

5. 默认登录账号
   用户名: admin
   密码: admin123

修改密码：
=========

编辑 docker-compose.yml 中的 ADMIN_USERNAME 和 ADMIN_PASSWORD，
然后重新启动: docker-compose up -d

常用命令：
=========

查看日志:   docker-compose logs -f finvue
停止服务:   docker-compose down
重启服务:   docker-compose restart
完全清理:   docker-compose down -v（会删除数据库数据）

注意：
=====

热点追踪功能需要外网代理才能访问微博、知乎等平台 API。
如果没有代理，热点追踪会失败，但其他功能正常使用。