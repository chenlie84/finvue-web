#!/usr/bin/env python3
"""
CSV数据导入脚本 - 导入直播/短视频/客户档案/客户会话数据到线上数据库
用法: python import_csv_to_production.py <csv文件> <类型>
类型: live, video, customer_profile, customer_session
"""

import csv
import sys
import hashlib
import json
from datetime import datetime
import pymysql

# 线上数据库配置
DB_CONFIG = {
    "host": "mysql0200.3337-wm.db.idc",
    "port": 3337,
    "database": "process_analysis",
    "user": "process_analysis",
    "password": "ns7ubvy96ncHncOTOeHS",
    "charset": "utf8mb4",
}

# ============== 字段映射 ==============

LIVE_FIELD_MAP = {
    # 基本信息
    "主播账号": "account", "account": "account",
    "直播间ID": "room_id", "roomId": "room_id",
    "直播标题": "title", "title": "title",
    "开播时间": "start_time", "startTime": "start_time",
    "关播时间": "end_time", "endTime": "end_time",
    "直播时长": "duration", "duration": "duration",
    "直播时长(分钟)": "duration", "直播时长（分钟）": "duration",
    "备注": "notes", "notes": "notes",
    # 人数
    "峰值在线人数": "pcu", "pcu": "pcu",
    "平均在线人数": "acu", "acu": "acu",
    "曝光人数": "show_ucnt", "showUcnt": "show_ucnt",
    "观看人数": "watch_ucnt", "watchUcnt": "watch_ucnt",
    "观看粉丝人数": "fans_watch_ucnt", "fansWatchUcnt": "fans_watch_ucnt",
    "观看非粉人数": "non_fans_watch_ucnt", "nonFansWatchUcnt": "non_fans_watch_ucnt",
    # 停留时长
    "人均停留时长": "avg_watch_duration", "avgWatchDuration": "avg_watch_duration",
    "粉丝人均停留时长": "fans_avg_watch_duration", "fansAvgWatchDuration": "fans_avg_watch_duration",
    "非粉人均停留时长": "non_fans_avg_watch_duration", "nonFansAvgWatchDuration": "non_fans_avg_watch_duration",
    # 涨粉
    "涨粉人数": "follow_ucnt", "followUcnt": "follow_ucnt",
    "涨粉率": "follow_u_rate", "followURate": "follow_u_rate",
    "掉粉人数": "unfollow_ucnt", "unfollowUcnt": "unfollow_ucnt",
    "加入粉丝团人数": "join_fansclub_ucnt", "joinFansclubUcnt": "join_fansclub_ucnt",
    # 互动
    "评论人数": "comment_ucnt", "commentUcnt": "comment_ucnt",
    "粉丝评论人数": "fans_comment_ucnt", "fansCommentUcnt": "fans_comment_ucnt",
    "非粉评论人数": "non_fans_comment_ucnt", "nonFansCommentUcnt": "non_fans_comment_ucnt",
    "点赞次数": "like_cnt", "likeCnt": "like_cnt",
    "粉丝点赞次数": "fans_like_cnt", "fansLikeCnt": "fans_like_cnt",
    "非粉点赞次数": "non_fans_like_cnt", "nonFansLikeCnt": "non_fans_like_cnt",
    "分享次数": "share_cnt", "shareCnt": "share_cnt",
    "粉丝分享次数": "fans_share_cnt", "fansShareCnt": "fans_share_cnt",
    "非粉分享次数": "non_fans_share_cnt", "nonFansShareCnt": "non_fans_share_cnt",
    # 收入
    "收入积分": "earn_score", "earnScore": "earn_score",
    "粉丝收入积分": "fans_earn_score", "fansEarnScore": "fans_earn_score",
    "非粉收入积分": "non_fans_earn_score", "nonFansEarnScore": "non_fans_earn_score",
    "付费人数": "consume_ucnt", "consumeUcnt": "consume_ucnt",
    "粉丝付费人数": "fans_consume_ucnt", "fansConsumeUcnt": "fans_consume_ucnt",
    "非粉付费人数": "non_fans_consume_ucnt", "nonFansConsumeUcnt": "non_fans_consume_ucnt",
}

VIDEO_FIELD_MAP = {
    "主播账号": "account", "account": "account",
    "视频ID": "video_id", "videoId": "video_id",
    "作品名称": "title", "title": "title",
    "发布时间": "publish_time", "publishTime": "publish_time",
    "体裁": "duration_type", "durationType": "duration_type",
    "播放量": "play_count", "playCount": "play_count",
    "点赞数": "like_count", "likeCount": "like_count",
    "评论数": "comment_count", "commentCount": "comment_count",
    "分享数": "share_count", "shareCount": "share_count",
    "完播率": "completion_rate", "completionRate": "completion_rate",
    "5秒完播率": "5s_completion_rate", "5sCompletionRate": "5s_completion_rate",
    "2秒流失率": "2s_exit_rate", "2sExitRate": "2s_exit_rate",
    "互动率": "interaction_rate", "interactionRate": "interaction_rate",
    "涨粉数": "follow_count", "followCount": "follow_count",
}

CUSTOMER_PROFILE_FIELD_MAP = {
    "客户ID": "customer_id", "customer_id": "customer_id", "customerId": "customer_id",
    "客户姓名": "customer_name", "customer_name": "customer_name", "customerName": "customer_name",
    "主播名称": "latest_anchor_name", "anchor_name": "latest_anchor_name", "anchorName": "latest_anchor_name",
    "分析时间": "latest_analyzed_at", "analyzed_at": "latest_analyzed_at", "analyzedAt": "latest_analyzed_at",
    "直播主题": "latest_live_theme", "live_theme": "latest_live_theme", "liveTheme": "latest_live_theme",
    "排名": "latest_rank", "rank": "latest_rank",
    "最高排名": "best_rank", "bestRank": "best_rank",
    "平均观看时长": "avg_watch_seconds", "avgWatchSeconds": "avg_watch_seconds",
    "标签": "labels", "labels": "labels",
    "标记": "tags", "tags": "tags",
}

CUSTOMER_SESSION_FIELD_MAP = {
    "会话ID": "session_id", "session_id": "session_id", "sessionId": "session_id",
    "客户ID": "customer_id", "customer_id": "customer_id", "customerId": "customer_id",
    "主播名称": "anchor_name", "anchorName": "anchor_name",
    "直播间ID": "room_id", "roomId": "room_id",
    "直播主题": "live_theme", "liveTheme": "live_theme",
    "报告类型": "report_type", "reportType": "report_type",
    "指标类型": "metric_type", "metricType": "metric_type",
    "指标值": "metric_value", "metricValue": "metric_value",
    "观看排名": "watch_rank", "watchRank": "watch_rank",
    "观看时长": "watch_duration_seconds", "watchDurationSeconds": "watch_duration_seconds",
    "分析时间": "analyzed_at", "analyzedAt": "analyzed_at",
    "来源文件": "source_file", "sourceFile": "source_file",
}


def parse_number(value):
    """解析数字"""
    if not value:
        return None
    value = str(value).strip().replace("%", "").replace(",", "")
    try:
        if "." in value:
            return float(value)
        return int(value)
    except:
        return None


def parse_datetime(value):
    """解析日期时间"""
    if not value:
        return None
    value = str(value).strip()
    formats = [
        "%Y-%m-%d %H:%M:%S", "%Y/%m/%d %H:%M:%S",
        "%Y-%m-%d %H:%M", "%Y/%m/%d %H:%M",
        "%Y-%m-%d", "%Y/%m/%d",
    ]
    for fmt in formats:
        try:
            return datetime.strptime(value, fmt).strftime("%Y-%m-%d %H:%M:%S")
        except:
            continue
    return None


def parse_json(value):
    """解析JSON"""
    if not value:
        return "[]"
    try:
        return json.dumps(json.loads(str(value)))
    except:
        return json.dumps([str(value).strip()])


def generate_id(*args):
    """生成唯一ID"""
    key = "_".join(str(a) for a in args)
    return hashlib.md5(key.encode()).hexdigest()[:19]


def get_field_mapping(headers, field_map):
    """获取字段映射"""
    mapping = {}
    for h in headers or []:
        h_clean = str(h or "").strip()
        if h_clean in field_map:
            mapping[h] = field_map[h_clean]
    return mapping


# ============== 导入函数 ==============

def import_live_csv(csv_path):
    """导入直播CSV"""
    conn = pymysql.connect(**DB_CONFIG)
    cursor = conn.cursor()
    imported, skipped, errors = 0, 0, []
    
    try:
        with open(csv_path, "r", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            field_mapping = get_field_mapping(reader.fieldnames, LIVE_FIELD_MAP)
            print(f"映射字段: {field_mapping}")
            
            for row in reader:
                try:
                    # 获取必填字段
                    account = next((str(row.get(k) or "").strip() for k, v in field_mapping.items() if v == "account"), None)
                    if not account:
                        skipped += 1
                        continue
                    
                    room_id = next((str(row.get(k) or "").strip() for k, v in field_mapping.items() if v == "room_id"), None)
                    start_time = next((parse_datetime(row.get(k)) for k, v in field_mapping.items() if v == "start_time"), None)
                    
                    if not room_id and start_time:
                        room_id = generate_id(account, start_time)
                    if not room_id:
                        skipped += 1
                        continue
                    
                    # 检查重复
                    cursor.execute("SELECT id FROM finvue_operation_live_stats WHERE room_id = %s", (room_id,))
                    if cursor.fetchone():
                        skipped += 1
                        print(f"跳过: {room_id}")
                        continue
                    
                    # 构建数据
                    data = {"account": account, "room_id": room_id}
                    
                    for csv_col, db_field in field_mapping.items():
                        if db_field in ["account", "room_id"]:
                            continue
                        value = row.get(csv_col)
                        if not value:
                            continue
                        
                        if db_field in ["start_time", "end_time", "created_at"]:
                            data[db_field] = parse_datetime(value)
                        elif db_field in ["duration", "pcu", "acu", "show_ucnt", "watch_ucnt",
                                         "fans_watch_ucnt", "non_fans_watch_ucnt", "follow_ucnt",
                                         "unfollow_ucnt", "join_fansclub_ucnt", "comment_ucnt",
                                         "fans_comment_ucnt", "non_fans_comment_ucnt",
                                         "like_cnt", "fans_like_cnt", "non_fans_like_cnt",
                                         "share_cnt", "fans_share_cnt", "non_fans_share_cnt",
                                         "earn_score", "fans_earn_score", "non_fans_earn_score",
                                         "consume_ucnt", "fans_consume_ucnt", "non_fans_consume_ucnt"]:
                            num = parse_number(value)
                            if num is not None:
                                data[db_field] = int(num) if isinstance(num, float) and num == int(num) else num
                        elif db_field in ["avg_watch_duration", "fans_avg_watch_duration",
                                         "non_fans_avg_watch_duration", "follow_u_rate",
                                         "watch_u_rate", "comment_u_rate", "consume_u_rate"]:
                            num = parse_number(value)
                            if num is not None:
                                data[db_field] = num
                        elif db_field in ["title", "notes"]:
                            data[db_field] = str(value).strip()
                    
                    # 插入
                    fields = list(data.keys())
                    sql = f"INSERT INTO finvue_operation_live_stats ({','.join(fields)}) VALUES ({','.join(['%s']*len(fields))})"
                    cursor.execute(sql, list(data.values()))
                    imported += 1
                    
                except Exception as e:
                    errors.append(str(e))
                    print(f"错误: {e}")
        
        conn.commit()
    finally:
        cursor.close()
        conn.close()
    
    return {"ok": True, "imported": imported, "skipped": skipped, "errors": errors}


def import_video_csv(csv_path):
    """导入短视频CSV"""
    conn = pymysql.connect(**DB_CONFIG)
    cursor = conn.cursor()
    imported, skipped, errors = 0, 0, []
    
    try:
        with open(csv_path, "r", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            field_mapping = get_field_mapping(reader.fieldnames, VIDEO_FIELD_MAP)
            print(f"映射字段: {field_mapping}")
            
            for row in reader:
                try:
                    account = next((str(row.get(k) or "").strip() for k, v in field_mapping.items() if v == "account"), None)
                    if not account:
                        skipped += 1
                        continue
                    
                    publish_time = next((parse_datetime(row.get(k)) for k, v in field_mapping.items() if v == "publish_time"), None)
                    title = next((str(row.get(k) or "").strip() for k, v in field_mapping.items() if v == "title"), None)
                    
                    data = {"account": account}
                    if publish_time:
                        data["publish_time"] = publish_time
                    if title:
                        data["title"] = title
                    
                    for csv_col, db_field in field_mapping.items():
                        if db_field in ["account", "publish_time", "title"]:
                            continue
                        value = row.get(csv_col)
                        if not value:
                            continue
                        
                        if db_field in ["play_count", "like_count", "comment_count", "share_count", "follow_count"]:
                            num = parse_number(value)
                            if num is not None:
                                data[db_field] = int(num)
                        elif db_field in ["completion_rate", "5s_completion_rate", "2s_exit_rate", "interaction_rate"]:
                            num = parse_number(value)
                            if num is not None:
                                data[db_field] = num
                        elif db_field in ["video_id", "duration_type"]:
                            data[db_field] = str(value).strip()
                    
                    # 检查重复
                    if data.get("title") and data.get("publish_time"):
                        cursor.execute(
                            "SELECT id FROM finvue_operation_video_stats WHERE account=%s AND title=%s AND publish_time=%s",
                            (account, data["title"], data["publish_time"])
                        )
                        if cursor.fetchone():
                            skipped += 1
                            continue
                    
                    fields = list(data.keys())
                    sql = f"INSERT INTO finvue_operation_video_stats ({','.join(fields)}) VALUES ({','.join(['%s']*len(fields))})"
                    cursor.execute(sql, list(data.values()))
                    imported += 1
                    
                except Exception as e:
                    errors.append(str(e))
                    print(f"错误: {e}")
        
        conn.commit()
    finally:
        cursor.close()
        conn.close()
    
    return {"ok": True, "imported": imported, "skipped": skipped, "errors": errors}


def import_customer_profile_csv(csv_path):
    """导入客户档案CSV"""
    conn = pymysql.connect(**DB_CONFIG)
    cursor = conn.cursor()
    imported, skipped, errors = 0, 0, []
    
    try:
        with open(csv_path, "r", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            field_mapping = get_field_mapping(reader.fieldnames, CUSTOMER_PROFILE_FIELD_MAP)
            print(f"映射字段: {field_mapping}")
            
            for row in reader:
                try:
                    customer_id = next((str(row.get(k) or "").strip() for k, v in field_mapping.items() if v == "customer_id"), None)
                    customer_name = next((str(row.get(k) or "").strip() for k, v in field_mapping.items() if v == "customer_name"), None)
                    
                    if not customer_id:
                        skipped += 1
                        continue
                    
                    # 检查重复
                    cursor.execute("SELECT customer_id FROM finvue_customer_profiles WHERE customer_id = %s", (customer_id,))
                    if cursor.fetchone():
                        skipped += 1
                        print(f"跳过: {customer_id}")
                        continue
                    
                    data = {
                        "customer_id": customer_id,
                        "customer_name": customer_name or customer_id,
                        "labels": "[]",
                        "tags": "[]",
                        "raw": "{}"
                    }
                    
                    for csv_col, db_field in field_mapping.items():
                        if db_field in ["customer_id", "customer_name", "labels", "tags", "raw"]:
                            continue
                        value = row.get(csv_col)
                        if not value:
                            continue
                        
                        if db_field in ["latest_analyzed_at"]:
                            data[db_field] = parse_datetime(value)
                        elif db_field in ["latest_rank", "best_rank", "avg_watch_seconds"]:
                            num = parse_number(value)
                            if num is not None:
                                data[db_field] = int(num)
                        elif db_field in ["latest_anchor_name", "latest_live_theme"]:
                            data[db_field] = str(value).strip()
                    
                    fields = list(data.keys())
                    sql = f"INSERT INTO finvue_customer_profiles ({','.join(fields)}) VALUES ({','.join(['%s']*len(fields))})"
                    cursor.execute(sql, list(data.values()))
                    imported += 1
                    
                except Exception as e:
                    errors.append(str(e))
                    print(f"错误: {e}")
        
        conn.commit()
    finally:
        cursor.close()
        conn.close()
    
    return {"ok": True, "imported": imported, "skipped": skipped, "errors": errors}


def import_customer_session_csv(csv_path):
    """导入客户会话CSV"""
    conn = pymysql.connect(**DB_CONFIG)
    cursor = conn.cursor()
    imported, skipped, errors = 0, 0, []
    
    try:
        with open(csv_path, "r", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            field_mapping = get_field_mapping(reader.fieldnames, CUSTOMER_SESSION_FIELD_MAP)
            print(f"映射字段: {field_mapping}")
            
            for row in reader:
                try:
                    customer_id = next((str(row.get(k) or "").strip() for k, v in field_mapping.items() if v == "customer_id"), None)
                    session_id = next((str(row.get(k) or "").strip() for k, v in field_mapping.items() if v == "session_id"), None)
                    
                    if not customer_id:
                        skipped += 1
                        continue
                    
                    # 检查客户是否存在
                    cursor.execute("SELECT customer_id FROM finvue_customer_profiles WHERE customer_id = %s", (customer_id,))
                    if not cursor.fetchone():
                        skipped += 1
                        print(f"客户不存在: {customer_id}")
                        continue
                    
                    # 生成session_id
                    anchor = next((str(row.get(k) or "").strip() for k, v in field_mapping.items() if v == "anchor_name"), "")
                    analyzed = next((parse_datetime(row.get(k)) or "" for k, v in field_mapping.items() if v == "analyzed_at"), "")
                    
                    if not session_id:
                        session_id = generate_id(customer_id, anchor, analyzed)
                    
                    # 检查会话重复
                    cursor.execute("SELECT session_id FROM finvue_customer_sessions WHERE session_id = %s", (session_id,))
                    if cursor.fetchone():
                        skipped += 1
                        continue
                    
                    data = {
                        "session_id": session_id,
                        "customer_id": customer_id,
                        "raw": "{}"
                    }
                    
                    for csv_col, db_field in field_mapping.items():
                        if db_field in ["session_id", "customer_id", "raw"]:
                            continue
                        value = row.get(csv_col)
                        if not value:
                            continue
                        
                        if db_field in ["analyzed_at"]:
                            data[db_field] = parse_datetime(value)
                        elif db_field in ["watch_rank", "watch_duration_seconds"]:
                            num = parse_number(value)
                            if num is not None:
                                data[db_field] = int(num)
                        elif db_field in ["anchor_name", "room_id", "live_theme", "report_type",
                                         "metric_type", "metric_value", "source_file"]:
                            data[db_field] = str(value).strip()
                    
                    fields = list(data.keys())
                    sql = f"INSERT INTO finvue_customer_sessions ({','.join(fields)}) VALUES ({','.join(['%s']*len(fields))})"
                    cursor.execute(sql, list(data.values()))
                    imported += 1
                    
                except Exception as e:
                    errors.append(str(e))
                    print(f"错误: {e}")
        
        conn.commit()
    finally:
        cursor.close()
        conn.close()
    
    return {"ok": True, "imported": imported, "skipped": skipped, "errors": errors}


# ============== 主函数 ==============

def main():
    if len(sys.argv) < 2:
        print("用法: python import_csv_to_production.py <csv文件> <类型>")
        print("类型: live, video, customer_profile, customer_session")
        print("\n示例:")
        print("  python import_csv_to_production.py live_data.csv live")
        print("  python import_csv_to_production.py video_data.csv video")
        print("  python import_csv_to_production.py customer_profiles.csv customer_profile")
        print("  python import_csv_to_production.py customer_sessions.csv customer_session")
        sys.exit(1)
    
    csv_path = sys.argv[1]
    import_type = sys.argv[2] if len(sys.argv) > 2 else "live"
    
    print("=" * 60)
    print(f"导入类型: {import_type}")
    print(f"CSV文件: {csv_path}")
    print(f"数据库: {DB_CONFIG['host']}:{DB_CONFIG['port']}/{DB_CONFIG['database']}")
    print("=" * 60)
    
    importers = {
        "live": import_live_csv,
        "video": import_video_csv,
        "customer_profile": import_customer_profile_csv,
        "customer_session": import_customer_session_csv,
    }
    
    if import_type not in importers:
        print(f"未知类型: {import_type}")
        print(f"支持的类型: {list(importers.keys())}")
        sys.exit(1)
    
    result = importers[import_type](csv_path)
    
    print("=" * 60)
    print(f"导入完成!")
    print(f"成功: {result['imported']} 条")
    print(f"跳过: {result['skipped']} 条")
    if result['errors']:
        print(f"错误: {len(result['errors'])} 条")
        for e in result['errors'][:5]:
            print(f"  - {e}")


if __name__ == "__main__":
    main()