FinVue Docker 部署说明（Mac & Windows 通用）
=============================================

部署步骤：
=========

1. 解压部署包
   - Mac: unzip finvue-deploy-source.zip
   - Windows: 右键解压或 Expand-Archive finvue-deploy-source.zip

2. 进入目录
   cd finvue-deploy-source

3. 构建并启动
   docker-compose up -d --build
   
   首次构建需要几分钟，之后启动不需要 --build

4. 访问应用
   http://localhost:8080

5. 默认登录账号
   用户名: admin
   密码: admin123

Windows 用户注意：
=================

如果拉取 MySQL 镜像失败，请配置 Docker 镜像加速器：
- Docker Desktop → Settings → Docker Engine
- 添加配置：
  {
    "registry-mirrors": [
      "https://docker.m.daocloud.io",
      "https://docker.nju.edu.cn"
    ]
  }
- Apply & Restart

修改密码：
=========

编辑 docker-compose.yml 中的 ADMIN_USERNAME 和 ADMIN_PASSWORD，
然后重新启动: docker-compose up -d

常用命令：
=========

查看日志:   docker-compose logs -f finvue
停止服务:   docker-compose down
重启服务:   docker-compose restart
完全清理:   docker-compose down -v（会删除数据库数据）

注意：
=====

热点追踪功能需要外网代理才能访问微博、知乎等平台 API。
如果没有代理，热点追踪会失败，但其他功能正常使用。