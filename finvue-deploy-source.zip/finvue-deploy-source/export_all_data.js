/**
 * 一次性导出四个数据文件
 * 1. customer_profiles_export.csv - 客户档案数据（本地finvue数据库）
 * 2. customer_sessions_export.csv - 客户直播场次数据（本地finvue数据库）
 * 3. live_data_export.csv - 所有主播直播数据（远程demo数据库）
 * 4. video_data_export.csv - 所有主播短视频数据（远程demo数据库）
 */

const mysql = require('mysql2/promise');
const fs = require('fs');

// 配置
const CONFIG = {
  // 本地 finvue 数据库（客户运营数据）
  local: {
    host: '127.0.0.1',
    port: 3306,
    user: 'root',
    password: 'Python3.8',
    database: 'finvue'
  },
  // 远程 demo 数据库（直播+短视频数据）
  remote: {
    host: '10.170.32.218',
    port: 3306,
    user: 'root',
    password: 'Python3.8',
    database: 'demo',
    connectTimeout: 30000
  },
  // 输出目录
  outputDir: '/Users/beeerjack/Desktop/develop/10-data'
};

// 格式化北京时间（UTC+8）
function formatBeijingTime(date) {
  if (!date) return '';
  const d = new Date(date);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  const hours = String(d.getHours()).padStart(2, '0');
  const minutes = String(d.getMinutes()).padStart(2, '0');
  const seconds = String(d.getSeconds()).padStart(2, '0');
  return year + '-' + month + '-' + day + ' ' + hours + ':' + minutes + ':' + seconds;
}

// CSV 转义
function csvEscape(val) {
  if (val === null || val === undefined) return '';
  if (typeof val === 'string') {
    return '"' + val.replace(/"/g, '""').replace(/\n/g, '') + '"';
  }
  return val;
}

// 导出 customer_profiles
async function exportCustomerProfiles(conn) {
  console.log('\n[1/4] 导出 customer_profiles...');

  const query = 'SELECT customer_id, customer_name, latest_anchor_name, latest_analyzed_at, latest_live_theme, latest_rank, best_rank, avg_watch_seconds, labels, tags, created_at, updated_at FROM customer_profiles ORDER BY updated_at DESC';

  const [rows] = await conn.query(query);
  console.log('  查询结果:', rows.length, '条');

  const headers = '客户ID,客户名称,主播名称,最近分析时间,最近直播主题,最近排名,最佳排名,平均观看时长,标签,标签2,创建时间,更新时间';
  let csv = headers + '\n';

  rows.forEach(r => {
    csv += [
      r.customer_id || '',
      csvEscape(r.customer_name),
      csvEscape(r.latest_anchor_name),
      formatBeijingTime(r.latest_analyzed_at),
      csvEscape(r.latest_live_theme),
      r.latest_rank || 0,
      r.best_rank || 0,
      r.avg_watch_seconds || 0,
      r.labels ? '"' + JSON.stringify(r.labels).replace(/"/g, '""') + '"' : '',
      r.tags ? '"' + JSON.stringify(r.tags).replace(/"/g, '""') + '"' : '',
      formatBeijingTime(r.created_at),
      formatBeijingTime(r.updated_at)
    ].join(',') + '\n';
  });

  const outputPath = CONFIG.outputDir + '/customer_profiles_export.csv';
  fs.writeFileSync(outputPath, csv, 'utf8');
  const sizeMB = Math.round(fs.statSync(outputPath).size / 1024 / 1024);
  console.log('  ✅ 导出完成:', outputPath, '(' + sizeMB + ' MB)');

  return { count: rows.length, size: sizeMB };
}

// 导出 customer_sessions
async function exportCustomerSessions(conn) {
  console.log('\n[2/4] 导出 customer_sessions...');

  const query = 'SELECT session_id, customer_id, anchor_name, room_id, live_theme, report_type, metric_type, metric_value, watch_rank, watch_duration_seconds, analyzed_at, source_file, created_at, updated_at FROM customer_sessions ORDER BY analyzed_at DESC';

  const [rows] = await conn.query(query);
  console.log('  查询结果:', rows.length, '条');

  const headers = '场次ID,客户ID,主播名称,直播间ID,直播主题,报告类型,指标类型,指标值,观看排名,观看时长秒,分析时间,来源文件,创建时间,更新时间';
  let csv = headers + '\n';

  rows.forEach(r => {
    csv += [
      r.session_id || '',
      r.customer_id || '',
      csvEscape(r.anchor_name),
      r.room_id || '',
      csvEscape(r.live_theme),
      r.report_type || '',
      r.metric_type || '',
      r.metric_value || '',
      r.watch_rank || 0,
      r.watch_duration_seconds || 0,
      formatBeijingTime(r.analyzed_at),
      csvEscape(r.source_file),
      formatBeijingTime(r.created_at),
      formatBeijingTime(r.updated_at)
    ].join(',') + '\n';
  });

  const outputPath = CONFIG.outputDir + '/customer_sessions_export.csv';
  fs.writeFileSync(outputPath, csv, 'utf8');
  const sizeMB = Math.round(fs.statSync(outputPath).size / 1024 / 1024);
  console.log('  ✅ 导出完成:', outputPath, '(' + sizeMB + ' MB)');

  return { count: rows.length, size: sizeMB };
}

// 导出 live_data
async function exportLiveData(conn) {
  console.log('\n[3/4] 导出 live_data (直播)...');

  const query = 'SELECT account, room_id, title, startTime, endTime, duration, pcu, acu, earnScore, fansEarnScore, nonFansEarnScore, firstEarnScore, consumeUcnt, fansConsumeUcnt, nonFansConsumeUcnt, firstConsumeUcnt, expectedTotalIncome, showUcnt, watchUcnt, fansWatchUcnt, nonFansWatchUcnt, followUcnt, unfollowUcnt, joinFansClubUcnt, avgWatchDuration, fansAvgWatchDuration, nonFansAvgWatchDuration, commentUcnt, fansCommentUcnt, nonFansCommentUcnt, likeCnt, fansLikeCnt, nonFansLikeCnt, shareCnt, fansShareCnt, nonFansShareCnt, fansInGroup, fansOutGroup, watchURate, followURate, commentURate, consumeURate, fansWatchURate, fansCommentURate, fansLikeRate, fansShareRate, fansConsumeURate, fansInGroupRate, created_at FROM douyin_creator_live_overview ORDER BY startTime DESC';

  const [rows] = await conn.query(query);
  console.log('  查询结果:', rows.length, '条');

  const headers = ['账号名称', '直播id', '直播标题', '开播时间', '关播时间', '直播时长', '峰值人数', '平均人数', '收获音浪', '粉丝音浪', '非粉音浪', '首次送礼用户音浪', '送礼人数', '送礼粉丝人数', '送礼非粉人数', '首次送礼人数', '预计收入', '曝光人数', '观看人数', '观看粉丝人数', '观看非粉人数', '涨粉人数', '掉粉人数', '加团人数', '人均停留时长', '粉丝人均停留时长', '非粉人均停留时长', '评论人数', '评论粉丝人数', '评论非粉人数', '点赞次数', '点赞粉丝次数', '点赞非粉次数', '分享次数', '分享粉丝次数', '分享非粉次数', '群内粉丝', '群外粉丝', '观看率', '涨粉率', '评论率', '送礼率', '粉丝观看率', '粉丝评论率', '粉丝点赞率', '粉丝分享率', '粉丝送礼率', '群内粉丝率', '创建时间'];

  let csv = headers.join(',') + '\n';

  rows.forEach(r => {
    csv += [r.account || '', r.room_id || '', csvEscape(r.title), formatBeijingTime(r.startTime), formatBeijingTime(r.endTime), r.duration || 0, r.pcu || 0, r.acu || 0, r.earnScore || 0, r.fansEarnScore || 0, r.nonFansEarnScore || 0, r.firstEarnScore || 0, r.consumeUcnt || 0, r.fansConsumeUcnt || 0, r.nonFansConsumeUcnt || 0, r.firstConsumeUcnt || 0, r.expectedTotalIncome || 0, r.showUcnt || 0, r.watchUcnt || 0, r.fansWatchUcnt || 0, r.nonFansWatchUcnt || 0, r.followUcnt || 0, r.unfollowUcnt || 0, r.joinFansClubUcnt || 0, r.avgWatchDuration || 0, r.fansAvgWatchDuration || 0, r.nonFansAvgWatchDuration || 0, r.commentUcnt || 0, r.fansCommentUcnt || 0, r.nonFansCommentUcnt || 0, r.likeCnt || 0, r.fansLikeCnt || 0, r.nonFansLikeCnt || 0, r.shareCnt || 0, r.fansShareCnt || 0, r.nonFansShareCnt || 0, r.fansInGroup || 0, r.fansOutGroup || 0, r.watchURate || 0, r.followURate || 0, r.commentURate || 0, r.consumeURate || 0, r.fansWatchURate || 0, r.fansCommentURate || 0, r.fansLikeRate || 0, r.fansShareRate || 0, r.fansConsumeURate || 0, r.fansInGroupRate || 0, formatBeijingTime(r.created_at)].join(',') + '\n';
  });

  const outputPath = CONFIG.outputDir + '/live_data_export.csv';
  fs.writeFileSync(outputPath, csv, 'utf8');
  const sizeKB = Math.round(fs.statSync(outputPath).size / 1024);
  console.log('  ✅ 导出完成:', outputPath, '(' + sizeKB + ' KB)');

  const anchorStats = {};
  rows.forEach(r => { const name = r.account || '未知'; anchorStats[name] = (anchorStats[name] || 0) + 1; });
  console.log('\n=== 各主播直播场次 ===');
  Object.keys(anchorStats).sort((a, b) => anchorStats[b] - anchorStats[a]).forEach(name => console.log('  ' + name + ': ' + anchorStats[name] + '场'));

  return { count: rows.length, size: sizeKB };
}

// 导出 video_data
async function exportVideoData(conn) {
  console.log('\n[4/4] 导出 video_data (短视频)...');

  const query = 'SELECT id, account, video_title, genre, publish_time, play_count, like_count, completion_rate, five_second_completion_rate, two_second_bounce_rate, share_count, comment_count, fan_increment, created_at FROM douyin_video_list ORDER BY publish_time DESC';

  const [rows] = await conn.query(query);
  console.log('  查询结果:', rows.length, '条');

  const headers = ['视频ID', '主播账号', '视频标题', '体裁', '发布时间', '播放量', '点赞数', '完播率', '5s完播率', '2s跳出率', '分享数', '评论数', '粉丝增量', '创建时间'];
  let csv = headers.join(',') + '\n';

  rows.forEach(r => {
    csv += [r.id || '', csvEscape(r.account), csvEscape(r.video_title), r.genre || '', formatBeijingTime(r.publish_time), r.play_count || 0, r.like_count || 0, r.completion_rate || 0, r.five_second_completion_rate || 0, r.two_second_bounce_rate || 0, r.share_count || 0, r.comment_count || 0, r.fan_increment || 0, formatBeijingTime(r.created_at)].join(',') + '\n';
  });

  const outputPath = CONFIG.outputDir + '/video_data_export.csv';
  fs.writeFileSync(outputPath, csv, 'utf8');
  const sizeKB = Math.round(fs.statSync(outputPath).size / 1024);
  console.log('  ✅ 导出完成:', outputPath, '(' + sizeKB + ' KB)');

  const anchorStats = {};
  rows.forEach(r => { const name = r.account || '未知'; anchorStats[name] = (anchorStats[name] || 0) + 1; });
  console.log('\n=== 各主播短视频数量 ===');
  Object.keys(anchorStats).sort((a, b) => anchorStats[b] - anchorStats[a]).forEach(name => console.log('  ' + name + ': ' + anchorStats[name] + '个'));

  return { count: rows.length, size: sizeKB };
}

// 主函数
async function main() {
  console.log('========================================');
  console.log('开始导出四个数据文件');
  console.log('时间:', new Date().toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' }));
  console.log('输出目录:', CONFIG.outputDir);
  console.log('========================================');

  const startTime = Date.now();

  try {
    const localPool = mysql.createPool(CONFIG.local);
    const localConn = await localPool.getConnection();
    const remotePool = mysql.createPool(CONFIG.remote);
    const remoteConn = await remotePool.getConnection();

    const result1 = await exportCustomerProfiles(localConn);
    const result2 = await exportCustomerSessions(localConn);
    const result3 = await exportLiveData(remoteConn);
    const result4 = await exportVideoData(remoteConn);

    localConn.release();
    remoteConn.release();
    localPool.end();
    remotePool.end();

    const elapsed = Math.round((Date.now() - startTime) / 1000);
    console.log('\n========================================');
    console.log('✅ 导出完成！');
    console.log('耗时:', elapsed, '秒');
    console.log('\n导出文件汇总:');
    console.log('  1. customer_profiles_export.csv:', result1.count, '条', '(' + result1.size + ' MB)');
    console.log('  2. customer_sessions_export.csv:', result2.count, '条', '(' + result2.size + ' MB)');
    console.log('  3. live_data_export.csv:', result3.count, '条', '(' + result3.size + ' KB)');
    console.log('  4. video_data_export.csv:', result4.count, '条', '(' + result4.size + ' KB)');
    console.log('\n输出目录:', CONFIG.outputDir);
    console.log('========================================');

  } catch (err) {
    console.error('\n❌ 导出失败:', err.message);
    console.error(err.stack);
    process.exit(1);
  }
}

main();
